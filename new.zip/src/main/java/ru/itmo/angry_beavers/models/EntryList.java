package ru.itmo.angry_beavers.models;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Deque;

public class EntryList implements Serializable {
	private final Deque<Entry> entries;
	private final SimpleDateFormat simpleDateFormat;
	
	public EntryList() {
		entries = new ArrayDeque<>();
		simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
	}
	
	public Deque<Entry> getEntries() {
		return entries;
	}
	
	public void addEntry(Entry entry) {
		entries.addFirst(entry);
	}
	
	public SimpleDateFormat getSimpleDateFormat() {
		return simpleDateFormat;
	}

//	private double getNumberView(double number) {
//		MathContext context = new MathContext(7, RoundingMode.HALF_UP);
//		BigDecimal result = new BigDecimal(number, context);
//		return Double.parseDouble(String.valueOf(result));
//	}
}
