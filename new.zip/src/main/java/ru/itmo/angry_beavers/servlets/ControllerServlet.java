package ru.itmo.angry_beavers.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/controller")
public class ControllerServlet extends HttpServlet {
	private static final double R_MAX_VALUE = 5;
	private static final double R_MIN_VALUE = 2;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			double x = Double.parseDouble(request.getParameter("x"));
			double y = Double.parseDouble(request.getParameter("y"));
			double r = Double.parseDouble(request.getParameter("r"));

//			response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "Error code");
			
			getServletContext().getRequestDispatcher("/area_check").forward(request, response);
//
//			if (r < R_MIN_VALUE || r > R_MAX_VALUE) {
//				getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
//			} else {
//				getServletContext().getRequestDispatcher("/check_area").forward(request, response);
//			}
		
		} catch (NumberFormatException | NullPointerException e) {
//			getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
		
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
