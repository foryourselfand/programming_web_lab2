package ru.itmo.angry_beavers.servlets;

import ru.itmo.angry_beavers.models.Entry;
import ru.itmo.angry_beavers.models.EntryList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

@WebServlet("/area_check")
public class AreaCheckServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double x = Double.parseDouble(request.getParameter("x"));
		double y = Double.parseDouble(request.getParameter("y"));
		double r = Double.parseDouble(request.getParameter("r"));
		boolean result = getResult(x, y, r);
		Date currentTime = new Date();
		
		Entry entry = new Entry(x, y, r, result, currentTime);
		
		HttpSession session = request.getSession();
		
		EntryList entries = (EntryList) session.getAttribute("entries");
		entries = entries == null ? new EntryList() : entries;
		
		entries.addEntry(entry);
		session.setAttribute("entries", entries);

//		response.sendRedirect("/answer.jsp");
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private boolean getResult(double x, double y, double r) {
		// 1 quarter
		
		boolean qOne = x >= 0 && y >= 0;
		if (qOne && y * y + x * x <= r * r) {
			return true;
		}
		
		// 2 quarter
		boolean qTwo = x <= 0 && y >= 0;
		if (qTwo && x >= - r / 2 && y <= 2 * x + r) {
			return true;
		}
		
		// 4 quarter
		boolean qFour = x >= 0 && y <= 0;
		return qFour && x <= r / 2 && y >= - r;
	}
}
